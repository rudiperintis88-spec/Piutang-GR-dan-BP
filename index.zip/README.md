# Perintis Group - Dashboard Gabungan

Isi: index.html (4 tab: Piutang Unit, BPKB Cash, Piutang GR & BP, Belum Buka Faktur), api/sheet.js, package.json.
Deploy ke Vercel dengan index.html dan api/sheet.js di folder yang sama.
Google Sheet harus dibagikan sebagai "Siapa saja yang memiliki link" (Viewer).

Catatan: kolom Nama SA, Keterangan, dan Alasan di tab Belum Buka Faktur dibaca dari sheet "Data SA" di Google Sheet yang sama
(Kode SA -> Nama SA, dan No PKB/WO -> Keterangan + Alasan). PKB/WO yang belum ada di "Data SA" tampil "-".

Sheet1 dibaca berdasarkan NAMA JUDUL kolom, bukan urutan, jadi kolom yang tidak terpakai boleh dihapus.
Judul wajib di Sheet1: "No PKB/WO" dan "Jumlah". Jangan mengganti nama judul kolom yang dipakai.

Aturan divisi (sama di halaman gabungan dan tiga halaman cabang):
- Nama: "Adam Malik" = GR Adam Malik | "Flamboyan Service" / "GR Flamboyan" = GR Flamboyan | "Flamboyan BP" / "Body Repair" = Body Repair
- Bila Divisi kosong (Sheet1 maupun PKB WIP), dibaca dari kode di nomor WO: PP = GR Adam Malik, PB = Body Repair, PF = GR Flamboyan

Tab PKB/WO (Work In Process): PKB/WO di sheet PKB WIP yang nomornya sudah ada di Sheet1 tidak ditampilkan lagi.
Contoh: PKB WIP 20 baris, 10 di antaranya sudah ada di Sheet1 -> tab WIP menampilkan 10 baris.

HARI DIHITUNG OTOMATIS oleh dashboard (kolom Hari dan kolom =today() di semua sheet sumber tidak dipakai lagi dan boleh dihapus):
- Material Belum Faktur: hari ini dikurangi TglWO; bila TglWO tidak ada, dikurangi TglSupply.
- Piutang GR & BP: hari ini dikurangi Tgl.Jto (negatif bila belum jatuh tempo). Tgl.Jto kosong -> Hari kosong.
- Piutang Unit: hari ini dikurangi Tgl.Jto. Tgl.Jto kosong / tidak terbaca -> 0.
- BPKB Cash: hari ini dikurangi Terima Tanggal BPKB (kolom K, jam ikut dihitung, dibulatkan). Terima Tanggal kosong -> umur kosong.
  Kategori < 60, > 60, > 90 hari mengikuti umur ini (kolom <60Hr, >60Hr, >90Hr di sheet tidak dipakai lagi).
Angka Hari berganti otomatis tiap hari. Format tanggal yang dikenali antara lain: dd/mm/yyyy, d-m-yyyy, dd.mm.yyyy, yyyy-mm-dd, "03 Agu 2026", "3 Agustus 2026".

BPKB Cash - Salesman, Supervisor, dan Divisi dibaca otomatis dari sheet "Data" (cocok dengan No. BAST), bukan dari kolom VLOOKUP di sheet cabang.
- Tiap unit ditempatkan di divisi sesuai sheet Data (Gatsu / Gagak Hitam / Flamboyan); bila divisinya tidak dikenal, dipakai nama sheet cabangnya.
- Kolom Salesman, Supervisor, Divisi, <60Hr, >60Hr, >90Hr, Hari, Today di sheet cabang boleh dihapus.
- Jangan ganti nama judul kolom "Leasing", "No. Bast", dan "Serah Tanggal" (dibaca lewat judul) maupun judul kolom di sheet Data (BAST, Salesman, Supervisor, Divisi).
- No. BAST yang tidak ada di sheet Data: Salesman dan Supervisor dikosongkan (atau memakai kolom lama bila masih ada di sheet cabang).

TGL BUAT TAGIHAN & TGL BARCODE (Piutang Unit, Followup Penagihan) dibaca dari sheet "Data PerFaktur" (cocok dengan Faktur No.), bukan dari kolom O/P Sheet1.
- Judul kolom yang dicari di sheet "Data PerFaktur": kolom berisi kata "Faktur" (Faktur No.), kolom berisi "Tagihan" (Tgl Buat Tagihan), kolom berisi "Barcode" (Tgl Barcode). Jangan ganti nama judul tersebut.
- Faktur yang tidak ada di sheet "Data PerFaktur" atau Tgl Buat Tagihan-nya kosong -> tampil "Belum Buat Tagihan". Tgl Barcode kosong -> "-".
- Dibaca lewat nama sheet, jadi file Google Sheet harus dibagikan "Siapa saja yang memiliki link" (Viewer). Bila tidak bisa dibagikan, isi konstanta PERFAKTUR_PUB_GID di kode dengan angka gid sheet "Data PerFaktur" (angka setelah #gid= di alamat sheet) dan pastikan sheet itu ikut di-publish ke web.
- Bila sheet "Data PerFaktur" belum bisa dibaca sama sekali, dashboard memakai kolom O/P Sheet1 seperti sebelumnya (tidak error).
- Kolom Tgl Buat Tagihan, Tgl Barcode di Sheet1 boleh dihapus setelah sheet "Data PerFaktur" terbaca normal.

PIUTANG (Piutang Unit, Followup Penagihan): Type, Divisi, Cara Pembelian, Leasing, Salesman, Supervisor dibaca dari sheet "Data", dicocokkan lewat Faktur No. (kolom C di sheet Data), bukan dari kolom Sheet1.
- Faktur yang belum ada di sheet "Data" memakai nilai Sheet1 sebagai cadangan. Kolom-kolom tersebut di Sheet1 boleh dihapus bila semua faktur sudah ada di sheet "Data".
