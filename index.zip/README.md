# Perintis Group - Dashboard Gabungan

Isi: index.html (4 tab: Piutang Unit, BPKB Cash, Piutang GR & BP, Belum Buka Faktur), api/sheet.js, package.json.
Deploy ke Vercel dengan index.html dan api/sheet.js di folder yang sama.
Google Sheet harus dibagikan sebagai "Siapa saja yang memiliki link" (Viewer).

Catatan: kolom Nama SA, Keterangan, dan Alasan di tab Belum Buka Faktur dibaca dari sheet "Data SA" di Google Sheet yang sama
(Kode SA -> Nama SA, dan No PKB/WO -> Keterangan + Alasan). PKB/WO yang belum ada di "Data SA" tampil "-".

Sheet1 dibaca berdasarkan NAMA JUDUL kolom, bukan urutan, jadi kolom yang tidak terpakai boleh dihapus.
Judul wajib di Sheet1: "No PKB/WO" dan "Jumlah". Jangan mengganti nama judul kolom yang dipakai.

Aturan divisi (sama di halaman gabungan dan tiga halaman cabang):
- Nama: "Adam Malik" = GR Adam Malik | "Flamboyan Service" / "GR Flamboyan" = GR Flamboyan | "Flamboyan BP" / "Body Repair" = Body Repair
- Bila Divisi kosong (Sheet1 maupun PKB WIP), dibaca dari kode di nomor WO: PP = GR Adam Malik, PB = Body Repair, PF = GR Flamboyan

Tab PKB/WO (Work In Process): PKB/WO di sheet PKB WIP yang nomornya sudah ada di Sheet1 tidak ditampilkan lagi.
Contoh: PKB WIP 20 baris, 10 di antaranya sudah ada di Sheet1 -> tab WIP menampilkan 10 baris.

HARI DIHITUNG OTOMATIS oleh dashboard (kolom Hari dan kolom =today() di semua sheet sumber tidak dipakai lagi dan boleh dihapus):
- Material Belum Faktur: hari ini dikurangi TglWO; bila TglWO tidak ada, dikurangi TglSupply.
- Piutang GR & BP: hari ini dikurangi Tgl.Jto (negatif bila belum jatuh tempo). Tgl.Jto kosong -> Hari kosong.
- Piutang Unit: hari ini dikurangi Tgl.Jto. Tgl.Jto kosong / tidak terbaca -> 0.
- BPKB Cash: hari ini dikurangi Terima Tanggal BPKB (kolom K, jam ikut dihitung, dibulatkan). Terima Tanggal kosong -> umur kosong.
  Kategori < 60, > 60, > 90 hari mengikuti umur ini (kolom <60Hr, >60Hr, >90Hr di sheet tidak dipakai lagi).
Angka Hari berganti otomatis tiap hari. Format tanggal yang dikenali antara lain: dd/mm/yyyy, d-m-yyyy, dd.mm.yyyy, yyyy-mm-dd, "03 Agu 2026", "3 Agustus 2026".
